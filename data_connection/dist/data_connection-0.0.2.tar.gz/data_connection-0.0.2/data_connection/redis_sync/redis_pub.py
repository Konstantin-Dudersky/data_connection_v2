class RedisPub:
    pass
